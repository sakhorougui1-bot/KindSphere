\# kind\_sphere



Auteur : \[Sakho Rougui (L3 INFO SI P34 2342) et Talla Hawa (L3 INFO SI P34 2345)]

Cours : \[DEV MOBILE]



\## Description

App mobile qui permet de gerer différents de moyens de faire des dons.





\## Lancer le projet

Prérequis : Flutter installé (https://docs.flutter.dev/get-started/install).



flutter pub get

flutter run -d chrome



\## Version utilisée

Flutter \[3.44.5]

