import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'firebase_options.dart';
import 'login_page.dart';
import 'signup_page.dart';
import 'views/home/home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const KindSphereApp());
}

class KindSphereApp extends StatelessWidget {
  const KindSphereApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KindSphere',
      theme: ThemeData(
        fontFamily: 'Arial',
        useMaterial3: true,
      ),
      home: const WelcomePage(),
    );
  }
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  // =====================================================
  // CONNEXION GOOGLE
  // =====================================================

  Future<void> _signInWithGoogle(BuildContext context) async {
    try {
      final GoogleSignIn googleSignIn = GoogleSignIn();

      // Ouvre réellement la connexion Google
      final GoogleSignInAccount? account =
          await googleSignIn.signIn();

      // L'utilisateur a annulé
      if (account == null) return;

      // Récupération des informations Google
      final GoogleSignInAuthentication googleAuth =
          await account.authentication;

      // Création du compte de connexion Firebase
      final OAuthCredential credential =
          GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // AUTHENTIFICATION FIREBASE
      final UserCredential userCredential =
          await FirebaseAuth.instance.signInWithCredential(
        credential,
      );

      // Vérification : Firebase doit réellement avoir connecté
      // l'utilisateur avant d'aller sur HomePage.
      if (userCredential.user == null) {
        throw Exception(
          'L’authentification Firebase a échoué.',
        );
      }

      if (!context.mounted) return;

      // Seulement maintenant → HomePage
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const HomePage(),
        ),
      );
    } on FirebaseAuthException catch (e) {
      if (!context.mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Erreur Firebase : ${e.message ?? 'connexion impossible.'}',
          ),
          backgroundColor: Colors.redAccent,
        ),
      );
    } catch (e) {
      if (!context.mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Erreur de connexion Google : $e',
          ),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // =================================================
          // IMAGE DE TA PAGE D'ACCUEIL
          // =================================================

          Positioned.fill(
            child: Image.asset(
              'assets/kindsphere.png',
              fit: BoxFit.cover,
            ),
          ),

          // =================================================
          // BOUTONS EN BAS
          // =================================================

          Positioned(
            left: 25,
            right: 25,
            bottom: 35,
            child: Column(
              children: [
                // =================================================
                // CONTINUER AVEC GOOGLE
                // =================================================

                Container(
                  width: double.infinity,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: TextButton(
                    onPressed: () {
                      _signInWithGoogle(context);
                    },
                    child: const Row(
                      mainAxisAlignment:
                          MainAxisAlignment.center,
                      children: [
                        Text(
                          'G',
                          style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF2196F3),
                          ),
                        ),
                        SizedBox(width: 14),
                        Text(
                          'Continuer avec Google',
                          style: TextStyle(
                            fontSize: 17,
                            color: Color(0xFF123B6D),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 15),

                // =================================================
                // CRÉER UN COMPTE
                // =================================================

                Container(
                  width: double.infinity,
                  height: 70,
                  decoration: BoxDecoration(
                    color: const Color(0xFF2196F3),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              const SignupPage(),
                        ),
                      );
                    },
                    child: const Text(
                      'Créer un compte',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 15),

                // =================================================
                // SE CONNECTER
                // =================================================

                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            const LoginPage(),
                      ),
                    );
                  },
                  child: const Text(
                    'Déjà un compte ? Se connecter',
                    style: TextStyle(
                      color: Color(0xFF123B6D),
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}