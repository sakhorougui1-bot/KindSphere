import 'package:flutter/material.dart';

class DonationTrackingPage extends StatelessWidget {
  final String needId;
  final String needTitle;
  final String donationType;

  const DonationTrackingPage({
    super.key,
    required this.needId,
    required this.needTitle,
    required this.donationType,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text('Suivi du don'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF123B6D),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  Color(0xFF1565C0),
                  Color(0xFF2196F3),
                ],
              ),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'DON #KS-001',
                  style: TextStyle(
                    color: Colors.white70,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  needTitle,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  donationType,
                  style: const TextStyle(
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
          const Text(
            'Traçabilité',
            style: TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.bold,
              color: Color(0xFF123B6D),
            ),
          ),
          const SizedBox(height: 20),
          _step(
            icon: Icons.check,
            title: 'Don enregistré',
            subtitle: 'Votre don a été enregistré.',
            active: true,
          ),
          _line(),
          _step(
            icon: Icons.verified_outlined,
            title: 'Don confirmé',
            subtitle: 'En attente de confirmation.',
            active: false,
          ),
          _line(),
          _step(
            icon: Icons.local_shipping_outlined,
            title: 'Collecte / traitement',
            subtitle: 'Votre don sera pris en charge.',
            active: false,
          ),
          _line(),
          _step(
            icon: Icons.inventory_2_outlined,
            title: 'Don reçu',
            subtitle: 'Le bénéficiaire reçoit votre aide.',
            active: false,
          ),
          _line(),
          _step(
            icon: Icons.favorite_outline,
            title: 'Besoin satisfait',
            subtitle: 'Objectif du besoin atteint.',
            active: false,
          ),
        ],
      ),
    );
  }

  Widget _step({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool active,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CircleAvatar(
          radius: 22,
          backgroundColor: active
              ? const Color(0xFF2196F3)
              : Colors.grey.shade200,
          child: Icon(
            icon,
            color: active ? Colors.white : Colors.grey,
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: active
                      ? Colors.black87
                      : Colors.grey.shade700,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                subtitle,
                style: TextStyle(
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _line() {
    return Container(
      margin: const EdgeInsets.only(left: 21),
      height: 35,
      width: 2,
      color: Colors.grey.shade300,
    );
  }
}