import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'donation_summary_page.dart';

class ShareDonationPage extends StatelessWidget {
  final String needId;
  final String needTitle;

  const ShareDonationPage({
    super.key,
    required this.needId,
    required this.needTitle,
  });

  @override
  Widget build(BuildContext context) {
    final link =
        'https://kindsphere.app/need/$needId';

    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text('Partager'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF123B6D),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 30),
            const CircleAvatar(
              radius: 42,
              backgroundColor: Color(0xFFE8F5FF),
              child: Icon(
                Icons.share_outlined,
                color: Color(0xFF2196F3),
                size: 42,
              ),
            ),
            const SizedBox(height: 22),
            const Text(
              'Partagez ce besoin',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF123B6D),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              needTitle,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.black54,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 25),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: SelectableText(link),
            ),
            const SizedBox(height: 15),
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton.icon(
                onPressed: () async {
                  await Clipboard.setData(
                    ClipboardData(text: link),
                  );

                  if (!context.mounted) return;

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Lien copié.'),
                    ),
                  );
                },
                icon: const Icon(Icons.copy),
                label: const Text('Copier le lien'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2196F3),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 15),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DonationSummaryPage(
                      needId: needId,
                      needTitle: needTitle,
                      type: 'partager',
                      itemDescription: link,
                    ),
                  ),
                );
              },
              child: const Text('Terminer'),
            ),
          ],
        ),
      ),
    );
  }
}