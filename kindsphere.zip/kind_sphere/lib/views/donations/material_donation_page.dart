import 'package:flutter/material.dart';
import 'donation_summary_page.dart';

class MaterialDonationPage extends StatefulWidget {
  final String needId;
  final String needTitle;
  final String typeTitle;

  const MaterialDonationPage({
    super.key,
    required this.needId,
    required this.needTitle,
    required this.typeTitle,
  });

  @override
  State<MaterialDonationPage> createState() =>
      _MaterialDonationPageState();
}

class _MaterialDonationPageState
    extends State<MaterialDonationPage> {
  final descriptionController = TextEditingController();
  final quantityController = TextEditingController();
  final addressController = TextEditingController();

  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  @override
  void dispose() {
    descriptionController.dispose();
    quantityController.dispose();
    addressController.dispose();
    super.dispose();
  }

  Future<void> chooseDate() async {
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(
        const Duration(days: 365),
      ),
      initialDate: DateTime.now(),
    );

    if (date != null) {
      setState(() {
        selectedDate = date;
      });
    }
  }

  Future<void> chooseTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (time != null) {
      setState(() {
        selectedTime = time;
      });
    }
  }

  void confirmDonation() {
    if (descriptionController.text.trim().isEmpty ||
        quantityController.text.trim().isEmpty ||
        addressController.text.trim().isEmpty ||
        selectedDate == null ||
        selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Veuillez remplir tous les champs.',
          ),
        ),
      );
      return;
    }

    final date =
        '${selectedDate!.day.toString().padLeft(2, '0')}/'
        '${selectedDate!.month.toString().padLeft(2, '0')}/'
        '${selectedDate!.year}';

    final time = selectedTime!.format(context);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DonationSummaryPage(
          needId: widget.needId,
          needTitle: widget.needTitle,
          type: widget.typeTitle.toLowerCase(),
          itemDescription:
              '${descriptionController.text.trim()} - '
              '${quantityController.text.trim()}',
          address: addressController.text.trim(),
          pickupDate: date,
          pickupTime: time,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: Text('Don de ${widget.typeTitle}'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF123B6D),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            widget.needTitle,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF123B6D),
            ),
          ),
          const SizedBox(height: 22),
          _field(
            controller: descriptionController,
            label: widget.typeTitle == 'Vêtements'
                ? 'Description des vêtements'
                : 'Description de la nourriture',
            icon: widget.typeTitle == 'Vêtements'
                ? Icons.checkroom_outlined
                : Icons.restaurant_outlined,
            maxLines: 2,
          ),
          const SizedBox(height: 14),
          _field(
            controller: quantityController,
            label: 'Quantité',
            icon: Icons.inventory_2_outlined,
          ),
          const SizedBox(height: 14),
          _field(
            controller: addressController,
            label: 'Adresse de récupération',
            icon: Icons.location_on_outlined,
            maxLines: 2,
          ),
          const SizedBox(height: 18),
          _selector(
            icon: Icons.calendar_today_outlined,
            text: selectedDate == null
                ? 'Choisir la date de récupération'
                : 'Date : ${selectedDate!.day.toString().padLeft(2, '0')}/'
                    '${selectedDate!.month.toString().padLeft(2, '0')}/'
                    '${selectedDate!.year}',
            onTap: chooseDate,
          ),
          const SizedBox(height: 12),
          _selector(
            icon: Icons.access_time_outlined,
            text: selectedTime == null
                ? 'Choisir l’heure de récupération'
                : 'Heure : ${selectedTime!.format(context)}',
            onTap: chooseTime,
          ),
          const SizedBox(height: 25),
          SizedBox(
            height: 56,
            child: ElevatedButton(
              onPressed: confirmDonation,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
              child: const Text(
                'Confirmer mon don',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _field({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    int maxLines = 1,
  }) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget _selector({
    required IconData icon,
    required String text,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15),
      child: Container(
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: const Color(0xFF2196F3),
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(text)),
            const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }
}