import 'package:flutter/material.dart';
import 'money_donation_page.dart';
import 'material_donation_page.dart';
import 'share_donation_page.dart';

class DonationTypePage extends StatelessWidget {
  final String needId;
  final String title;

  const DonationTypePage({
    super.key,
    required this.needId,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text('Je veux aider'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF123B6D),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.bold,
              color: Color(0xFF123B6D),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Choisissez le type de don que vous souhaitez faire.',
            style: TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 25),
          _card(
            context,
            icon: Icons.payments_outlined,
            title: 'Argent',
            subtitle: 'Faire un don financier',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MoneyDonationPage(
                    needId: needId,
                    needTitle: title,
                  ),
                ),
              );
            },
          ),
          _card(
            context,
            icon: Icons.checkroom_outlined,
            title: 'Vêtements',
            subtitle: 'Donner des vêtements',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MaterialDonationPage(
                    needId: needId,
                    needTitle: title,
                    typeTitle: 'Vêtements',
                  ),
                ),
              );
            },
          ),
          _card(
            context,
            icon: Icons.restaurant_outlined,
            title: 'Nourriture',
            subtitle: 'Donner de la nourriture',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MaterialDonationPage(
                    needId: needId,
                    needTitle: title,
                    typeTitle: 'Nourriture',
                  ),
                ),
              );
            },
          ),
          _card(
            context,
            icon: Icons.share_outlined,
            title: 'Partager',
            subtitle: 'Partager ce besoin autour de vous',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ShareDonationPage(
                    needId: needId,
                    needTitle: title,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _card(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(15),
        onTap: onTap,
        leading: Container(
          width: 55,
          height: 55,
          decoration: BoxDecoration(
            color: const Color(0xFFE8F5FF),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Icon(
            icon,
            color: const Color(0xFF2196F3),
            size: 28,
          ),
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 17,
          ),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(subtitle),
        ),
        trailing: const Icon(
          Icons.chevron_right,
          color: Color(0xFF2196F3),
        ),
      ),
    );
  }
}