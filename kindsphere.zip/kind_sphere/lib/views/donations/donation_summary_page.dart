import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'donation_tracking_page.dart';

class DonationSummaryPage extends StatelessWidget {
  final String needId;
  final String needTitle;
  final String type;
  final double? amount;
  final String? itemDescription;
  final String? address;
  final String? pickupDate;
  final String? pickupTime;
  final bool isAnonymous;

  const DonationSummaryPage({
    super.key,
    required this.needId,
    required this.needTitle,
    required this.type,
    this.amount,
    this.itemDescription,
    this.address,
    this.pickupDate,
    this.pickupTime,
    this.isAnonymous = false,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text('Résumé du don'),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF123B6D),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const SizedBox(height: 15),
          const CircleAvatar(
            radius: 40,
            backgroundColor: Color(0xFFE8F8EE),
            child: Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 50,
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Don enregistré ❤️',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF123B6D),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Merci pour votre générosité.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 25),
          _summary(),
          const SizedBox(height: 20),
          SizedBox(
            height: 55,
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DonationTrackingPage(
                      needId: needId,
                      needTitle: needTitle,
                      donationType: type,
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.location_searching),
              label: const Text(
                'Suivre mon don',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summary() {
    final user = FirebaseAuth.instance.currentUser;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        children: [
          _row('Besoin', needTitle),
          _row('Type', type),
          if (amount != null)
            _row('Montant', '${amount!.toStringAsFixed(0)} FCFA'),
          if (itemDescription != null)
            _row('Don', itemDescription!),
          if (address != null)
            _row('Adresse', address!),
          if (pickupDate != null)
            _row('Date', pickupDate!),
          if (pickupTime != null)
            _row('Heure', pickupTime!),
          _row(
            'Donateur',
            isAnonymous
                ? 'Anonyme'
                : user?.email ?? 'Utilisateur',
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(
                Icons.schedule,
                color: Colors.orange,
              ),
              const SizedBox(width: 8),
              Text(
                'En attente',
                style: TextStyle(
                  color: Colors.orange.shade800,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.black54,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}