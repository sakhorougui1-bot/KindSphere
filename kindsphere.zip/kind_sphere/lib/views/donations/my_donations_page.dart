import 'package:flutter/material.dart';
import 'donation_tracking_page.dart';

class MyDonationsPage extends StatelessWidget {
  const MyDonationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text('Mes dons'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF123B6D),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _donationCard(
            context,
            title: 'Hôpital Principal de Dakar',
            description: '20 poches de sang',
            type: 'Sang',
            status: 'En cours',
            color: const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _donationCard(
            context,
            title: 'Famille démunie',
            description: 'Panier alimentaire',
            type: 'Nourriture',
            status: 'Terminé',
            color: Colors.green,
          ),
          const SizedBox(height: 12),
          _donationCard(
            context,
            title: 'Daara',
            description: 'Vêtements',
            type: 'Vêtements',
            status: 'En attente',
            color: Colors.orange,
          ),
        ],
      ),
    );
  }

  Widget _donationCard(
    BuildContext context, {
    required String title,
    required String description,
    required String type,
    required String status,
    required Color color,
  }) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => DonationTrackingPage(
              needId: 'demo',
              needTitle: title,
              donationType: type,
            ),
          ),
        );
      },
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            Container(
              width: 55,
              height: 55,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(
                Icons.volunteer_activism_outlined,
                color: color,
              ),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    description,
                    style: TextStyle(
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    type,
                    style: const TextStyle(
                      color: Color(0xFF2196F3),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              status,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}