import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'donation_summary_page.dart';

class MoneyDonationPage extends StatefulWidget {
  final String needId;
  final String needTitle;

  const MoneyDonationPage({
    super.key,
    required this.needId,
    required this.needTitle,
  });

  @override
  State<MoneyDonationPage> createState() => _MoneyDonationPageState();
}

class _MoneyDonationPageState extends State<MoneyDonationPage> {
  final amountController = TextEditingController();
  String? paymentMethod;
  bool anonymous = false;

  @override
  void dispose() {
    amountController.dispose();
    super.dispose();
  }

  void continueDonation() {
    final amount = double.tryParse(
      amountController.text.trim(),
    );

    if (amount == null || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Veuillez saisir un montant valide.'),
        ),
      );
      return;
    }

    if (paymentMethod == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Choisissez Wave ou Orange Money.'),
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DonationSummaryPage(
          needId: widget.needId,
          needTitle: widget.needTitle,
          type: 'argent',
          amount: amount,
          itemDescription: paymentMethod,
          isAnonymous: anonymous,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text('Don financier'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF123B6D),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          _header(),
          const SizedBox(height: 25),
          const Text(
            'Montant du don',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: amountController,
            keyboardType: const TextInputType.numberWithOptions(
              decimal: true,
            ),
            decoration: InputDecoration(
              hintText: 'Exemple : 5000',
              suffixText: 'FCFA',
              filled: true,
              fillColor: Colors.white,
              prefixIcon: const Icon(
                Icons.payments_outlined,
                color: Color(0xFF2196F3),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            'Mode de paiement',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          _paymentTile('Wave', Icons.account_balance_wallet_outlined),
          const SizedBox(height: 10),
          _paymentTile('Orange Money', Icons.phone_android_outlined),
          const SizedBox(height: 15),
          SwitchListTile(
            value: anonymous,
            onChanged: (value) {
              setState(() {
                anonymous = value;
              });
            },
            title: const Text('Faire ce don anonymement'),
            activeColor: const Color(0xFF2196F3),
            contentPadding: EdgeInsets.zero,
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 56,
            child: ElevatedButton(
              onPressed: continueDonation,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
              child: const Text(
                'Continuer',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _header() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF1565C0),
            Color(0xFF2196F3),
          ],
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Text(
        'Votre aide pour ${widget.needTitle}',
        style: const TextStyle(
          color: Colors.white,
          fontSize: 17,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _paymentTile(String title, IconData icon) {
    final selected = paymentMethod == title;

    return InkWell(
      onTap: () {
        setState(() {
          paymentMethod = title;
        });
      },
      borderRadius: BorderRadius.circular(15),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: selected
                ? const Color(0xFF2196F3)
                : Colors.grey.shade200,
            width: selected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: const Color(0xFF2196F3),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Icon(
              selected
                  ? Icons.radio_button_checked
                  : Icons.radio_button_off,
              color: selected
                  ? const Color(0xFF2196F3)
                  : Colors.grey,
            ),
          ],
        ),
      ),
    );
  }
}