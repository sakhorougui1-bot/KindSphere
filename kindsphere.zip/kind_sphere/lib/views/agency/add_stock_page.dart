import 'package:flutter/material.dart';

import '../../models/stock_model.dart';

class AddStockPage extends StatefulWidget {
  const AddStockPage({super.key});

  @override
  State<AddStockPage> createState() => _AddStockPageState();
}

class _AddStockPageState extends State<AddStockPage> {
  static const Color _dark = Color(0xFF123B6D);

  final _donorController = TextEditingController();
  final _titleController = TextEditingController();
  final _quantityController = TextEditingController();
  final _unitController = TextEditingController(text: 'unités');

  DonorType _donorType = DonorType.association;
  StockCategory _category = StockCategory.nourriture;

  @override
  void dispose() {
    _donorController.dispose();
    _titleController.dispose();
    _quantityController.dispose();
    _unitController.dispose();
    super.dispose();
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }

  void _save() {
    final donor = _donorController.text.trim();
    final title = _titleController.text.trim();
    final quantity = int.tryParse(_quantityController.text.trim());
    final unit = _unitController.text.trim();

    if (donor.isEmpty) return _showError('Indiquez le nom du donateur.');
    if (title.isEmpty) return _showError('Indiquez ce qui a été reçu.');
    if (quantity == null || quantity <= 0) {
      return _showError('Indiquez une quantité valide.');
    }

    StockRepository.instance.add(
      StockItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        donorName: donor,
        donorType: _donorType,
        title: title,
        category: _category,
        quantity: quantity,
        unit: unit.isEmpty ? 'unités' : unit,
        receivedAt: DateTime.now(),
      ),
    );

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Stock enregistré.'),
        backgroundColor: Colors.green,
      ),
    );
  }

  InputDecoration _decoration(String label, {String? hint}) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text(
          'NOUVEAU STOCK',
          style: TextStyle(
              color: _dark,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.1),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _dark),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Enregistrer un gros don reçu d’une association ou d’une fondation.',
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 18),
            DropdownButtonFormField<DonorType>(
              value: _donorType,
              decoration: _decoration('Type de donateur'),
              items: [
                for (final t in DonorType.values)
                  DropdownMenuItem(value: t, child: Text(t.label)),
              ],
              onChanged: (v) => setState(() => _donorType = v ?? _donorType),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _donorController,
              decoration: _decoration('Nom du donateur',
                  hint: 'Ex : Fondation Teranga'),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _titleController,
              decoration: _decoration('Ce qui a été reçu',
                  hint: 'Ex : Sacs de riz 50 kg'),
            ),
            const SizedBox(height: 14),
            DropdownButtonFormField<StockCategory>(
              value: _category,
              decoration: _decoration('Catégorie'),
              items: [
                for (final c in StockCategory.values)
                  DropdownMenuItem(value: c, child: Text(c.label)),
              ],
              onChanged: (v) => setState(() => _category = v ?? _category),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _quantityController,
                    keyboardType: TextInputType.number,
                    decoration: _decoration('Quantité', hint: 'Ex : 200'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _unitController,
                    decoration: _decoration('Unité', hint: 'sacs, pièces...'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2196F3),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: _save,
                child: const Text('Enregistrer le stock',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
