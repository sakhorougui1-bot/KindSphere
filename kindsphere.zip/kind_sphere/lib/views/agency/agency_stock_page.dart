import 'package:flutter/material.dart';

import '../../models/stock_model.dart';
import 'add_stock_page.dart';
import 'stock_detail_page.dart';

class AgencyStockPage extends StatefulWidget {
  const AgencyStockPage({super.key});

  @override
  State<AgencyStockPage> createState() => _AgencyStockPageState();
}

class _AgencyStockPageState extends State<AgencyStockPage> {
  static const Color _dark = Color(0xFF123B6D);
  StockCategory? _filter;

  @override
  Widget build(BuildContext context) {
    final repo = StockRepository.instance;

    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text(
          'GESTION DES STOCKS',
          style: TextStyle(
            color: _dark,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.1,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _dark),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF2196F3),
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Nouveau stock',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddStockPage()),
          );
        },
      ),
      body: ValueListenableBuilder<List<StockItem>>(
        valueListenable: repo.items,
        builder: (context, all, _) {
          final list = _filter == null
              ? all
              : all.where((s) => s.category == _filter).toList();
          final enStock =
              all.where((s) => s.status != StockStatus.distribue).length;
          final distribues =
              all.where((s) => s.status == StockStatus.distribue).length;

          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 90),
            children: [
              Row(
                children: [
                  _summary('Total', '${all.length}', Colors.blue),
                  const SizedBox(width: 10),
                  _summary('En stock', '$enStock', Colors.orange),
                  const SizedBox(width: 10),
                  _summary('Distribués', '$distribues', Colors.green),
                ],
              ),
              const SizedBox(height: 18),

              SizedBox(
                height: 36,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _chip('Tous', _filter == null, () {
                      setState(() => _filter = null);
                    }),
                    for (final c in StockCategory.values)
                      _chip(c.label, _filter == c, () {
                        setState(() => _filter = c);
                      }),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              if (list.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 60),
                  child: Center(
                    child: Text('Aucun stock dans cette catégorie.',
                        style: TextStyle(color: Colors.grey)),
                  ),
                ),

              for (final s in list) _stockCard(context, s),
            ],
          );
        },
      ),
    );
  }

  Widget _summary(String label, String value, MaterialColor color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: [
            Text(value,
                style: TextStyle(
                    fontSize: 22, fontWeight: FontWeight.bold, color: color)),
            const SizedBox(height: 2),
            Text(label,
                style: TextStyle(fontSize: 12, color: Colors.grey[600])),
          ],
        ),
      ),
    );
  }

  Widget _chip(String label, bool selected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? Colors.blue : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: selected ? Colors.blue : Colors.grey.shade300),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : Colors.grey[700],
            fontSize: 13,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _stockCard(BuildContext context, StockItem s) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => StockDetailPage(stockId: s.id)),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: Colors.blue.shade50,
                  child: Icon(s.category.icon, color: Colors.blue),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(s.title,
                          style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: _dark)),
                      const SizedBox(height: 2),
                      Text('${s.donorType.label} : ${s.donorName}',
                          style:
                              TextStyle(fontSize: 12, color: Colors.grey[600])),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: s.status.color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(s.status.label,
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: s.status.color)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: s.progress,
                minHeight: 6,
                backgroundColor: Colors.grey.shade200,
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${s.distributed} / ${s.quantity} ${s.unit} distribués  •  Reçu le ${formatDate(s.receivedAt)}',
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
          ],
        ),
      ),
    );
  }
}
