import 'package:flutter/material.dart';

import '../../models/stock_model.dart';

class StockDetailPage extends StatelessWidget {
  final String stockId;

  const StockDetailPage({super.key, required this.stockId});

  static const Color _dark = Color(0xFF123B6D);

  Future<void> _openDistributionDialog(
      BuildContext context, StockItem item) async {
    final beneficiaryController = TextEditingController();
    final quantityController = TextEditingController();

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Enregistrer une distribution'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: beneficiaryController,
                decoration: const InputDecoration(
                  labelText: 'Structure bénéficiaire',
                  hintText: 'Ex : Daara Daroul Hikma',
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: quantityController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Quantité (${item.unit})',
                  helperText: 'Restant : ${item.remaining}',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Annuler'),
            ),
            ElevatedButton(
              onPressed: () {
                final beneficiary = beneficiaryController.text.trim();
                final qty = int.tryParse(quantityController.text.trim());
                String? error;
                if (beneficiary.isEmpty) {
                  error = 'Indiquez la structure bénéficiaire.';
                } else if (qty == null) {
                  error = 'Indiquez une quantité valide.';
                } else {
                  error = StockRepository.instance.distribute(
                    item.id,
                    Distribution(
                      beneficiary: beneficiary,
                      quantity: qty,
                      date: DateTime.now(),
                    ),
                  );
                }
                if (error != null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content: Text(error),
                        backgroundColor: Colors.redAccent),
                  );
                  return;
                }
                Navigator.pop(dialogContext);
              },
              child: const Text('Valider'),
            ),
          ],
        );
      },
    );

    beneficiaryController.dispose();
    quantityController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text(
          'DÉTAIL DU STOCK',
          style: TextStyle(
              color: _dark,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.1),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _dark),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ValueListenableBuilder<List<StockItem>>(
        valueListenable: StockRepository.instance.items,
        builder: (context, _, __) {
          final item = StockRepository.instance.byId(stockId);
          if (item == null) {
            return const Center(child: Text('Stock introuvable.'));
          }

          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: Colors.blue.shade50,
                          child: Icon(item.category.icon, color: Colors.blue),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(item.title,
                              style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: _dark)),
                        ),
                        Text(item.status.label,
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: item.status.color)),
                      ],
                    ),
                    const SizedBox(height: 14),
                    _row('Donateur',
                        '${item.donorType.label} : ${item.donorName}'),
                    _row('Catégorie', item.category.label),
                    _row('Date de réception', formatDate(item.receivedAt)),
                    _row('Quantité reçue', '${item.quantity} ${item.unit}'),
                    _row('Distribué', '${item.distributed} ${item.unit}'),
                    _row('Restant', '${item.remaining} ${item.unit}'),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: item.progress,
                        minHeight: 8,
                        backgroundColor: Colors.grey.shade200,
                        valueColor: const AlwaysStoppedAnimation<Color>(
                            Colors.green),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text('Suivi de la distribution',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: _dark)),
              const SizedBox(height: 10),
              if (item.distributions.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Text('Aucune distribution enregistrée pour le moment.',
                      style: TextStyle(color: Colors.grey)),
                ),
              for (final d in item.distributions)
                Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    leading: const Icon(Icons.local_shipping_outlined,
                        color: Colors.green),
                    title: Text(d.beneficiary,
                        style: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600)),
                    subtitle: Text(formatDate(d.date)),
                    trailing: Text('${d.quantity} ${item.unit}',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              const SizedBox(height: 16),
              SizedBox(
                height: 52,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2196F3),
                    disabledBackgroundColor: Colors.grey.shade300,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: item.remaining > 0
                      ? () => _openDistributionDialog(context, item)
                      : null,
                  icon: const Icon(Icons.add_task, color: Colors.white),
                  label: const Text('Enregistrer une distribution',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 130,
            child: Text(label,
                style: TextStyle(fontSize: 13, color: Colors.grey[600])),
          ),
          Expanded(
            child: Text(value,
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}
