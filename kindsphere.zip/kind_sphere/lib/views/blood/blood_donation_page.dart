import 'package:flutter/material.dart';
import '../donations/donation_summary_page.dart';

class BloodDonationPage extends StatefulWidget {
  final String needId;
  final String title;

  const BloodDonationPage({
    super.key,
    required this.needId,
    required this.title,
  });

  @override
  State<BloodDonationPage> createState() => _BloodDonationPageState();
}

class _BloodDonationPageState extends State<BloodDonationPage> {
  final _formKey = GlobalKey<FormState>();

  String? _bloodGroup;
  bool _knowsBloodGroup = true;
  bool _medicalHistory = false;
  bool _recentIllness = false;
  bool _takingMedication = false;
  bool _previousDonor = false;

  DateTime? _lastDonationDate;

  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _medicalDetailsController =
      TextEditingController();

  @override
  void dispose() {
    _phoneController.dispose();
    _medicalDetailsController.dispose();
    super.dispose();
  }

  Future<void> _selectLastDonationDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
    );

    if (date != null) {
      setState(() {
        _lastDonationDate = date;
      });
    }
  }

  void _continue() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_knowsBloodGroup && _bloodGroup == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Veuillez sélectionner votre groupe sanguin.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    if (_phoneController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Veuillez renseigner votre numéro de téléphone.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DonationSummaryPage(
  needId: widget.needId,
  needTitle: widget.title,
  type: 'Don de sang',
  itemDescription:
      'Groupe sanguin : ${_knowsBloodGroup ? (_bloodGroup ?? 'Non renseigné') : 'Inconnu'}\n'
      'Antécédents médicaux : ${_medicalHistory ? 'Oui' : 'Non'}\n'
      'Maladie récente : ${_recentIllness ? 'Oui' : 'Non'}\n'
      'Médicaments : ${_takingMedication ? 'Oui' : 'Non'}\n'
      'Donneur précédent : ${_previousDonor ? 'Oui' : 'Non'}\n'
      'Téléphone : ${_phoneController.text.trim()}',
),
      ),
    );
  }

  Widget _yesNoSwitch({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text(
          'Don de sang',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF123B6D),
        elevation: 0,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFF1565C0),
                      Color(0xFF2196F3),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.bloodtype,
                      color: Colors.white,
                      size: 38,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Votre don peut sauver une vie ❤️',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Renseignez quelques informations afin de préparer votre don.',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Groupe sanguin',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text(
                  'Je connais mon groupe sanguin',
                  style: TextStyle(fontSize: 14),
                ),
                value: _knowsBloodGroup,
                onChanged: (value) {
                  setState(() {
                    _knowsBloodGroup = value;
                    if (!value) {
                      _bloodGroup = null;
                    }
                  });
                },
              ),
              if (_knowsBloodGroup)
                DropdownButtonFormField<String>(
                  value: _bloodGroup,
                  decoration: InputDecoration(
                    labelText: 'Groupe sanguin',
                    prefixIcon: const Icon(Icons.bloodtype),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'A+', child: Text('A+')),
                    DropdownMenuItem(value: 'A-', child: Text('A-')),
                    DropdownMenuItem(value: 'B+', child: Text('B+')),
                    DropdownMenuItem(value: 'B-', child: Text('B-')),
                    DropdownMenuItem(value: 'AB+', child: Text('AB+')),
                    DropdownMenuItem(value: 'AB-', child: Text('AB-')),
                    DropdownMenuItem(value: 'O+', child: Text('O+')),
                    DropdownMenuItem(value: 'O-', child: Text('O-')),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _bloodGroup = value;
                    });
                  },
                ),
              const SizedBox(height: 24),
              const Text(
                'Informations de santé',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              _yesNoSwitch(
                title: 'Antécédents médicaux',
                subtitle: 'Avez-vous des antécédents médicaux importants ?',
                value: _medicalHistory,
                onChanged: (value) {
                  setState(() {
                    _medicalHistory = value;
                  });
                },
              ),
              _yesNoSwitch(
                title: 'Maladie récente',
                subtitle: 'Avez-vous été malade récemment ?',
                value: _recentIllness,
                onChanged: (value) {
                  setState(() {
                    _recentIllness = value;
                  });
                },
              ),
              _yesNoSwitch(
                title: 'Médicaments',
                subtitle: 'Prenez-vous actuellement des médicaments ?',
                value: _takingMedication,
                onChanged: (value) {
                  setState(() {
                    _takingMedication = value;
                  });
                },
              ),
              _yesNoSwitch(
                title: 'Avez-vous déjà donné votre sang ?',
                subtitle: 'Indiquez si vous êtes déjà donneur.',
                value: _previousDonor,
                onChanged: (value) {
                  setState(() {
                    _previousDonor = value;
                  });
                },
              ),
              if (_previousDonor)
                InkWell(
                  onTap: _selectLastDonationDate,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.calendar_month,
                          color: Colors.blue,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            _lastDonationDate == null
                                ? 'Date de votre dernier don'
                                : 'Dernier don : ${_lastDonationDate!.day}/${_lastDonationDate!.month}/${_lastDonationDate!.year}',
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _medicalDetailsController,
                maxLines: 3,
                decoration: InputDecoration(
                  labelText: 'Précisions médicales (facultatif)',
                  hintText: 'Vous pouvez ajouter une précision...',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Numéro obligatoire';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Numéro de téléphone',
                  prefixIcon: const Icon(Icons.phone),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: Colors.orange,
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Ces informations servent à préparer votre dossier. '
                        'L’éligibilité au don sera confirmée par un professionnel de santé.',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: _continue,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2196F3),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    'Continuer',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}