import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../donations/need_detail_page.dart';
import '../donations/my_donations_page.dart';
import '../blood/blood_donation_page.dart';
import '../needs/report_need_page.dart';
import '../../profile/profile_page.dart'; // Import de la page profil

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedCategoryIndex = 0;
  int _currentBottomNavIndex = 0;

  String _firstName() {
    final user = FirebaseAuth.instance.currentUser;
    final displayName = (user?.displayName ?? '').trim();
    String name;
    if (displayName.isNotEmpty) {
      name = displayName.split(' ').first;
    } else {
      final email = user?.email ?? '';
      name = email.isNotEmpty ? email.split('@').first : 'ami';
    }
    return name[0].toUpperCase() + name.substring(1);
  }

  final List<String> _categories = [
    'Tous',
    'Santé',
    'Daara',
    'Aînés',
    'Familles',
    'Nourriture',
    'Logement',
  ];

  final List<Map<String, dynamic>> _needs = [
    {
      'id': 'hopital_dakar',
      'title': 'Hôpital Principal de Dakar',
      'description': 'Besoin urgent : 20 poches de sang',
      'category': 'Santé',
      'image': 'assets/hopital.jpeg',
      'progress': 0.4,
      'urgent': true,
    },
    {
      'id': 'famille_pikine',
      'title': 'Famille démunie à Pikine',
      'description': 'Panier alimentaire & vêtements',
      'category': 'Familles',
      'image': 'assets/famille_demunie.jpeg',
      'progress': 0.15,
      'urgent': false,
    },
    {
      'id': 'daara_daroul_hikma',
      'title': 'Daara Daroul Hikma',
      'description': 'Fournitures & soutien',
      'category': 'Daara',
      'image': 'assets/daara.jpeg',
      'progress': 0.25,
      'urgent': false,
    },
    {
      'id': 'retraite_medina',
      'title': 'Maison de Retraite Médina',
      'description': 'Accompagnement & équipements',
      'category': 'Aînés',
      'image': 'assets/personnes_agees.jpeg',
      'progress': 0.6,
      'urgent': false,
    },
  ];

  List<Map<String, dynamic>> get _filteredNeeds {
    if (_selectedCategoryIndex == 0) {
      return _needs;
    }

    final selectedCategory = _categories[_selectedCategoryIndex];

    return _needs
        .where((need) => need['category'] == selectedCategory)
        .toList();
  }

  void _openNeed(Map<String, dynamic> need) {
    if (need['id'] == 'hopital_dakar') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BloodDonationPage(
            needId: need['id'],
            title: need['title'],
          ),
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => NeedDetailPage(
          needId: need['id'],
          title: need['title'],
          description: need['description'],
          category: need['category'],
          imageUrl: need['image'],
          progress: need['progress'],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSearch(),
                    const SizedBox(height: 20),
                    _buildQuranCard(),
                    const SizedBox(height: 25),
                    _buildSectionTitle(
                      'Catégories',
                      'Voir tout',
                    ),
                    const SizedBox(height: 12),
                    _buildCategories(),
                    const SizedBox(height: 25),
                    _buildSectionTitle(
                      'Besoins près de vous',
                      'Voir tout',
                    ),
                    const SizedBox(height: 14),
                    _buildNeeds(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 15),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFFE5F3FF),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              Icons.volunteer_activism,
              color: Color(0xFF2196F3),
              size: 28,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Bonjour, ${_firstName()} 👋',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF123B6D),
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'Chaque geste compte ❤️',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.black54,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: IconButton(
              onPressed: () {},
              icon: const Icon(
                Icons.notifications_none,
                color: Color(0xFF123B6D),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearch() {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: const TextField(
        decoration: InputDecoration(
          hintText: 'Rechercher un besoin...',
          hintStyle: TextStyle(
            color: Colors.grey,
            fontSize: 14,
          ),
          prefixIcon: Icon(
            Icons.search,
            color: Color(0xFF2196F3),
          ),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(vertical: 15),
        ),
      ),
    );
  }

  Widget _buildQuranCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF123B6D),
            Color(0xFF2196F3),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.format_quote,
            color: Colors.white70,
            size: 30,
          ),
          SizedBox(height: 8),
          Text(
            '« Et tout ce que vous dépensez de vos biens, '
            'Allah le remplacera. »',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
              height: 1.5,
            ),
          ),
          SizedBox(height: 10),
          Text(
            'Sourate Saba, 34:39',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, String action) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF123B6D),
          ),
        ),
        TextButton(
          onPressed: () {},
          child: const Text(
            'Voir tout',
            style: TextStyle(
              color: Color(0xFF2196F3),
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCategories() {
    return SizedBox(
      height: 42,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _categories.length,
        itemBuilder: (context, index) {
          final selected = _selectedCategoryIndex == index;

          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedCategoryIndex = index;
              });
            },
            child: Container(
              margin: const EdgeInsets.only(right: 10),
              padding: const EdgeInsets.symmetric(horizontal: 18),
              decoration: BoxDecoration(
                color: selected
                    ? const Color(0xFF2196F3)
                    : Colors.white,
                borderRadius: BorderRadius.circular(22),
              ),
              alignment: Alignment.center,
              child: Text(
                _categories[index],
                style: TextStyle(
                  color: selected
                      ? Colors.white
                      : const Color(0xFF123B6D),
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildNeeds() {
    final needs = _filteredNeeds;

    if (needs.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(30),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
        ),
        child: const Column(
          children: [
            Icon(
              Icons.search_off,
              size: 50,
              color: Colors.grey,
            ),
            SizedBox(height: 10),
            Text(
              'Aucun besoin trouvé',
              style: TextStyle(
                color: Colors.black54,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      children: needs.map((need) {
        return _buildNeedCard(need);
      }).toList(),
    );
  }

  Widget _buildNeedCard(Map<String, dynamic> need) {
    final double progress = need['progress'];

    return GestureDetector(
      onTap: () => _openNeed(need),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Image.asset(
                  need['image'],
                  width: double.infinity,
                  height: 175,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) {
                    return Container(
                      width: double.infinity,
                      height: 175,
                      color: const Color(0xFFE5F3FF),
                      child: const Center(
                        child: Icon(
                          Icons.volunteer_activism,
                          size: 55,
                          color: Color(0xFF2196F3),
                        ),
                      ),
                    );
                  },
                ),
                if (need['urgent'] == true)
                  Positioned(
                    top: 12,
                    left: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 11,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        'URGENT',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    need['category'],
                    style: const TextStyle(
                      color: Color(0xFF2196F3),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    need['title'],
                    style: const TextStyle(
                      color: Color(0xFF123B6D),
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    need['description'],
                    style: const TextStyle(
                      color: Colors.black54,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 14),
                  LinearProgressIndicator(
                    value: progress,
                    minHeight: 8,
                    borderRadius: BorderRadius.circular(20),
                    backgroundColor: Colors.grey.shade200,
                    valueColor: const AlwaysStoppedAnimation(
                      Color(0xFF2196F3),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${(progress * 100).round()}% financé',
                        style: const TextStyle(
                          color: Color(0xFF2196F3),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Text(
                        'Je veux aider →',
                        style: TextStyle(
                          color: Color(0xFF123B6D),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: _currentBottomNavIndex,
      type: BottomNavigationBarType.fixed,
      selectedItemColor: const Color(0xFF2196F3),
      unselectedItemColor: Colors.grey,
      backgroundColor: Colors.white,
      onTap: (index) {
        if (index == 2) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const ReportNeedPage(),
            ),
          );
          return;
        }

        if (index == 3) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const MyDonationsPage(),
            ),
          );
          return;
        }

        if (index == 4) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const ProfilePage(),
            ),
          );
          return;
        }

        setState(() {
          _currentBottomNavIndex = index;
        });
      },
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_outlined),
          activeIcon: Icon(Icons.home),
          label: 'Accueil',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.volunteer_activism_outlined),
          activeIcon: Icon(Icons.volunteer_activism),
          label: 'Besoins',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.add_circle_outline),
          activeIcon: Icon(Icons.add_circle),
          label: 'Proposer',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.favorite_border),
          activeIcon: Icon(Icons.favorite),
          label: 'Dons',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person_outline),
          activeIcon: Icon(Icons.person),
          label: 'Profil',
        ),
      ],
    );
  }
}