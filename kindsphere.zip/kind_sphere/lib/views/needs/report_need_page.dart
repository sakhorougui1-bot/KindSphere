import 'package:flutter/material.dart';

class ReportNeedPage extends StatefulWidget {
  const ReportNeedPage({super.key});

  @override
  State<ReportNeedPage> createState() => _ReportNeedPageState();
}

class _ReportNeedPageState extends State<ReportNeedPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController =
      TextEditingController();
  final TextEditingController _beneficiaryController =
      TextEditingController();
  final TextEditingController _locationController =
      TextEditingController();
  final TextEditingController _quantityController =
      TextEditingController();

  String _category = 'Santé';
  String _urgency = 'Important';

  final List<String> _categories = [
    'Santé',
    'Familles',
    'Daara',
    'Aînés',
    'Nourriture',
    'Logement',
    'Vêtements',
    'Autre',
  ];

  final List<String> _urgencies = [
    'Normal',
    'Important',
    'Urgent',
  ];

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _beneficiaryController.dispose();
    _locationController.dispose();
    _quantityController.dispose();
    super.dispose();
  }

  void _submitNeed() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          icon: const Icon(
            Icons.check_circle,
            color: Colors.green,
            size: 55,
          ),
          title: const Text(
            'Besoin envoyé',
            textAlign: TextAlign.center,
          ),
          content: const Text(
            'Merci pour votre initiative ❤️\n\n'
            'Votre demande sera vérifiée avant d’être publiée sur SadaqaLink.',
            textAlign: TextAlign.center,
          ),
          actions: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(dialogContext);
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2196F3),
                  foregroundColor: Colors.white,
                ),
                child: const Text('Retour à l’accueil'),
              ),
            ),
          ],
        );
      },
    );
  }

  InputDecoration _decoration({
    required String label,
    required IconData icon,
    String? hint,
  }) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: Icon(icon),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade200),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(
          color: Colors.blue,
          width: 1.5,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text(
          'Signaler un besoin',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF123B6D),
        elevation: 0,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFF1565C0),
                      Color(0xFF2196F3),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.volunteer_activism,
                      color: Colors.white,
                      size: 38,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Vous connaissez quelqu’un qui a besoin d’aide ?',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Décrivez le besoin. Notre équipe pourra ensuite vérifier les informations.',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Informations du besoin',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: _decoration(
                  label: 'Catégorie',
                  icon: Icons.category_outlined,
                ),
                items: _categories.map((category) {
                  return DropdownMenuItem(
                    value: category,
                    child: Text(category),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      _category = value;
                    });
                  }
                },
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _titleController,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Veuillez donner un titre au besoin';
                  }
                  return null;
                },
                decoration: _decoration(
                  label: 'Titre du besoin',
                  icon: Icons.title,
                  hint: 'Ex : Besoin de nourriture pour une famille',
                ),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _descriptionController,
                maxLines: 5,
                validator: (value) {
                  if (value == null || value.trim().length < 10) {
                    return 'Décrivez davantage le besoin';
                  }
                  return null;
                },
                decoration: _decoration(
                  label: 'Décrivez le besoin',
                  icon: Icons.description_outlined,
                  hint: 'Expliquez précisément la situation...',
                ),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _beneficiaryController,
                decoration: _decoration(
                  label: 'Personne ou organisation concernée',
                  icon: Icons.person_outline,
                  hint: 'Ex : Famille, hôpital, daara...',
                ),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _locationController,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Veuillez indiquer la localisation';
                  }
                  return null;
                },
                decoration: _decoration(
                  label: 'Localisation',
                  icon: Icons.location_on_outlined,
                  hint: 'Ex : Pikine, Dakar',
                ),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _quantityController,
                keyboardType: TextInputType.text,
                decoration: _decoration(
                  label: 'Montant ou quantité nécessaire',
                  icon: Icons.inventory_2_outlined,
                  hint: 'Ex : 20 000 FCFA ou 10 paniers',
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Niveau d’urgence',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: _urgencies.map((urgency) {
                  final selected = _urgency == urgency;

                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _urgency = urgency;
                        });
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 6),
                        padding: const EdgeInsets.symmetric(
                          vertical: 13,
                        ),
                        decoration: BoxDecoration(
                          color: selected
                              ? Colors.blue
                              : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: selected
                                ? Colors.blue
                                : Colors.grey.shade300,
                          ),
                        ),
                        child: Text(
                          urgency,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: selected
                                ? Colors.white
                                : Colors.grey[700],
                            fontWeight: selected
                                ? FontWeight.bold
                                : FontWeight.normal,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.verified_user_outlined,
                      color: Colors.blue,
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Les besoins signalés sont soumis à une vérification '
                        'avant leur publication afin de protéger les bénéficiaires et les donateurs.',
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: _submitNeed,
                  icon: const Icon(Icons.send),
                  label: const Text(
                    'Envoyer le besoin',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2196F3),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}