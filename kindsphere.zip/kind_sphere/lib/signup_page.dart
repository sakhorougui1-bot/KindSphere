import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'views/home/home_page.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  // Contrôleurs des champs
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  // Firebase Authentication
  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool isLoading = false;

  // Fonction de création du compte
  Future<void> creerCompte() async {
    String name = nameController.text.trim();
    String email = emailController.text.trim();
    String password = passwordController.text;

    // Vérification du nom
    if (name.isEmpty) {
      afficherMessage('Veuillez renseigner votre nom complet.');
      return;
    }

    // Vérification de l'email
    if (email.isEmpty) {
      afficherMessage('Veuillez renseigner votre adresse email.');
      return;
    }

    // Vérification simple de l'email
    if (!email.contains('@') || !email.contains('.')) {
      afficherMessage('Veuillez entrer une adresse email valide.');
      return;
    }

    // Vérification du mot de passe
    if (password.isEmpty) {
      afficherMessage('Veuillez renseigner votre mot de passe.');
      return;
    }

    if (password.length < 6) {
      afficherMessage(
        'Le mot de passe doit contenir au moins 6 caractères.',
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      // Création réelle du compte dans Firebase
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      await credential.user?.updateDisplayName(name);

      if (!mounted) return;

      afficherMessage('Compte créé avec succès !');

      // Aller vers HomePage après création réussie
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const HomePage(),
        ),
      );
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;

      if (e.code == 'email-already-in-use') {
        afficherMessage(
          'Cette adresse email est déjà utilisée.',
        );
      } else if (e.code == 'invalid-email') {
        afficherMessage(
          'Cette adresse email est invalide.',
        );
      } else if (e.code == 'weak-password') {
        afficherMessage(
          'Le mot de passe est trop faible.',
        );
      } else {
        afficherMessage(
          'Impossible de créer le compte. Veuillez réessayer.',
        );
      }
    } catch (e) {
      if (!mounted) return;

      afficherMessage(
        'Une erreur est survenue. Veuillez réessayer.',
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  // Afficher un message
  void afficherMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Fond
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFFE8F7FF),
                  Color(0xFFB9E6FA),
                ],
              ),
            ),
          ),

          // Contenu
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(25),
              child: Column(
                children: [
                  const SizedBox(height: 60),

                  // LOGO
                  Image.asset(
                    'assets/kindsphere.png',
                    height: 110,
                  ),

                  const SizedBox(height: 15),

                  // TITRE
                  const Text(
                    'Créer un compte',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF123B6D),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // NOM COMPLET
                  TextField(
                    controller: nameController,
                    decoration: InputDecoration(
                      labelText: 'Nom complet',
                      prefixIcon: const Icon(
                        Icons.person_outline,
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),

                  // EMAIL
                  TextField(
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      labelText: 'Adresse email',
                      prefixIcon: const Icon(
                        Icons.email_outlined,
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),

                  // MOT DE PASSE
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: 'Mot de passe',
                      prefixIcon: const Icon(
                        Icons.lock_outline,
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // BOUTON CREER MON COMPTE
                  Container(
                    width: double.infinity,
                    height: 55,
                    decoration: BoxDecoration(
                      color: const Color(0xFF2196F3),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: TextButton(
                      onPressed: isLoading ? null : creerCompte,
                      child: isLoading
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                              ),
                            )
                          : const Text(
                              'Créer mon compte',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // RETOUR
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text(
                      'J’ai déjà un compte',
                      style: TextStyle(
                        color: Color(0xFF123B6D),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}