import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'firebase_options.dart';
import 'login_page.dart';
import 'signup_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const KindSphereApp());
}

class KindSphereApp extends StatelessWidget {
  const KindSphereApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KindSphere',
      theme: ThemeData(
        fontFamily: 'Arial',
        useMaterial3: true,
      ),
      home: const WelcomePage(),
    );
  }
}

// =====================================================
// PAGE DE BIENVENUE
// =====================================================

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  // ===================================================
  // CONNEXION GOOGLE
  // ===================================================

  Future<void> _signInWithGoogle(BuildContext context) async {
    try {
      // 1. Déclencher le flux OAuth classique (v6.2.1)
      final GoogleSignInAccount? account = await GoogleSignIn().signIn();

      if (account == null) return; // Annulation par l'utilisateur

      // 2. Récupérer les informations d'authentification
      final GoogleSignInAuthentication googleAuth = await account.authentication;

      // 3. Créer le credential pour Firebase avec idToken et accessToken
      final OAuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // 4. Authentification Firebase
      final userCredential =
          await FirebaseAuth.instance.signInWithCredential(credential);

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Bienvenue ${userCredential.user?.displayName ?? account.displayName ?? 'Utilisateur'} !',
            ),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erreur de connexion Google : $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  // ===================================================
  // BUILD
  // ===================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // IMAGE DE FOND
          Positioned.fill(
            child: Image.asset(
              'assets/kindsphere.png',
              fit: BoxFit.cover,
            ),
          ),

          // BOUTONS
          Positioned(
            left: 25,
            right: 25,
            bottom: 35,
            child: Column(
              children: [
                // CONTINUER AVEC GOOGLE
                Container(
                  width: double.infinity,
                  height: 55,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: TextButton(
                    onPressed: () => _signInWithGoogle(context),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'G',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue,
                          ),
                        ),
                        SizedBox(width: 12),
                        Text(
                          'Continuer avec Google',
                          style: TextStyle(
                            fontSize: 16,
                            color: Color(0xFF123B6D),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // CRÉER UN COMPTE
                Container(
                  width: double.infinity,
                  height: 55,
                  decoration: BoxDecoration(
                    color: const Color(0xFF2196F3),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SignupPage(),
                        ),
                      );
                    },
                    child: const Text(
                      'Créer un compte',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 8),

                // SE CONNECTER
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const LoginPage(),
                      ),
                    );
                  },
                  child: const Text(
                    'Déjà un compte ? Se connecter',
                    style: TextStyle(
                      color: Color(0xFF123B6D),
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}