import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'home_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool isLoading = false;

  // ============================================================
  // CONNEXION AVEC EMAIL + MOT DE PASSE
  // ============================================================

  Future<void> seConnecter() async {
    final String email = emailController.text.trim();
    final String password = passwordController.text;

    if (email.isEmpty) {
      afficherMessage('Veuillez renseigner votre adresse email.');
      return;
    }

    if (!email.contains('@') || !email.contains('.')) {
      afficherMessage('Veuillez entrer une adresse email valide.');
      return;
    }

    if (password.isEmpty) {
      afficherMessage('Veuillez renseigner votre mot de passe.');
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const HomePage(),
        ),
      );
    } on FirebaseAuthException catch (e) {
      String message;

      switch (e.code) {
        case 'user-not-found':
          message = 'Aucun compte ne correspond à cette adresse email.';
          break;

        case 'wrong-password':
        case 'invalid-credential':
          message = 'Adresse email ou mot de passe incorrect.';
          break;

        case 'invalid-email':
          message = 'L’adresse email est invalide.';
          break;

        case 'user-disabled':
          message = 'Ce compte a été désactivé.';
          break;

        case 'too-many-requests':
          message = 'Trop de tentatives. Réessayez plus tard.';
          break;

        default:
          message = 'Erreur de connexion : ${e.message}';
      }

      afficherMessage(message);
    } catch (e) {
      afficherMessage('Une erreur est survenue.');
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  // ============================================================
  // MOT DE PASSE OUBLIÉ
  // ============================================================

  Future<void> motDePasseOublie() async {
    final String email = emailController.text.trim();

    if (email.isEmpty) {
      afficherMessage(
        'Veuillez renseigner votre adresse email avant de continuer.',
      );
      return;
    }

    if (!email.contains('@') || !email.contains('.')) {
      afficherMessage('Veuillez entrer une adresse email valide.');
      return;
    }

    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(
        email: email,
      );

      afficherMessage(
        'Un email de récupération a été envoyé à $email.',
      );
    } on FirebaseAuthException catch (e) {
      String message;

      switch (e.code) {
        case 'user-not-found':
          message = 'Aucun compte trouvé avec cette adresse email.';
          break;

        case 'invalid-email':
          message = 'L’adresse email est invalide.';
          break;

        case 'too-many-requests':
          message = 'Trop de demandes. Réessayez plus tard.';
          break;

        default:
          message = 'Impossible d’envoyer l’email de récupération.';
      }

      afficherMessage(message);
    } catch (e) {
      afficherMessage('Une erreur est survenue.');
    }
  }

  // ============================================================
  // CONNEXION AVEC GOOGLE
  // ============================================================

  Future<void> continuerAvecGoogle() async {
    setState(() {
      isLoading = true;
    });

    try {
      // 1. Lancement de la connexion Google (Version 6.x)
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

      if (googleUser == null) {
        // Connexion annulée par l'utilisateur
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
        return;
      }

      // 2. Récupération des jetons d'authentification
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      // 3. Création des identifiants Firebase avec accessToken et idToken
      final OAuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // 4. Connexion à Firebase
      await FirebaseAuth.instance.signInWithCredential(credential);

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const HomePage(),
        ),
      );
    } on FirebaseAuthException catch (e) {
      afficherMessage(
        'Erreur Firebase : ${e.message ?? 'connexion impossible.'}',
      );
    } catch (e) {
      afficherMessage(
        'Impossible de se connecter avec Google : $e',
      );
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void afficherMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  // ============================================================
  // INTERFACE
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFFE8F7FF),
                  Color(0xFFB9E6FA),
                ],
              ),
            ),
          ),

          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(25),
              child: Column(
                children: [
                  const SizedBox(height: 70),

                  Image.asset(
                    'assets/kindsphere.png',
                    height: 130,
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    'Bon retour !',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF123B6D),
                    ),
                  ),

                  const SizedBox(height: 8),

                  const Text(
                    'Connectez-vous à KindSphere',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                  ),

                  const SizedBox(height: 35),

                  // EMAIL
                  TextField(
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      labelText: 'Adresse email',
                      prefixIcon: const Icon(
                        Icons.email_outlined,
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),

                  // MOT DE PASSE
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: 'Mot de passe',
                      prefixIcon: const Icon(
                        Icons.lock_outline,
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),

                  // MOT DE PASSE OUBLIÉ
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed:
                          isLoading ? null : motDePasseOublie,
                      child: const Text(
                        'Mot de passe oublié ?',
                      ),
                    ),
                  ),

                  const SizedBox(height: 5),

                  // BOUTON SE CONNECTER
                  Container(
                    width: double.infinity,
                    height: 55,
                    decoration: BoxDecoration(
                      color: const Color(0xFF2196F3),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: TextButton(
                      onPressed:
                          isLoading ? null : seConnecter,
                      child: isLoading
                          ? const SizedBox(
                              height: 24,
                              width: 24,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                              ),
                            )
                          : const Text(
                              'Se connecter',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // OU
                  const Row(
                    children: [
                      Expanded(
                        child: Divider(),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: 10,
                        ),
                        child: Text(
                          'OU',
                          style: TextStyle(
                            color: Colors.black54,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Divider(),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // GOOGLE
                  SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: OutlinedButton.icon(
                      onPressed:
                          isLoading ? null : continuerAvecGoogle,
                      icon: Image.asset(
                        'assets/google_logo.png',
                        height: 24,
                        errorBuilder:
                            (context, error, stackTrace) {
                          return const Icon(
                            Icons.login,
                          );
                        },
                      ),
                      label: const Text(
                        'Continuer avec Google',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Colors.white,
                        side: const BorderSide(
                          color: Colors.black12,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(15),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),

                  // RETOUR
                  TextButton(
                    onPressed: isLoading
                        ? null
                        : () {
                            Navigator.pop(context);
                          },
                    child: const Text(
                      'Retour',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}