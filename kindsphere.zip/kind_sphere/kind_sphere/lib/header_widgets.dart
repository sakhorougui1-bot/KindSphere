import 'package:flutter/material.dart';

class HeaderWidget extends StatelessWidget {
  final String backgroundImagePath;
  final double height;

  const HeaderWidget({
    super.key,
    required this.backgroundImagePath,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: Stack(
        children: [

          // Image KindSphere
          Positioned.fill(
            child: Image.asset(
              backgroundImagePath,
              fit: BoxFit.cover,
            ),
          ),

        ],
      ),
    );
  }
}