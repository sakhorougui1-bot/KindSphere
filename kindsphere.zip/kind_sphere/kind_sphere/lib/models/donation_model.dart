enum DonationType { argent, sang, vetements, nourriture }
enum DonationStatus { enAttente, collecte, enTransit, livre }

class DonationModel {
  final String id;
  final String needId;
  final String donorId;
  final DonationType type;
  final double? amount;
  final String? itemDescription;
  final bool isAnonymous;
  final DonationStatus status;
  final String? proofImageUrl;
  final DateTime createdAt;

  DonationModel({
    required this.id,
    required this.needId,
    required this.donorId,
    required this.type,
    this.amount,
    this.itemDescription,
    this.isAnonymous = false,
    this.status = DonationStatus.enAttente,
    this.proofImageUrl,
    required this.createdAt,
  });

  factory DonationModel.fromMap(Map<String, dynamic> map, String id) {
    return DonationModel(
      id: id,
      needId: map['needId'] ?? '',
      donorId: map['donorId'] ?? '',
      type: DonationType.values.firstWhere((e) => e.name == map['type']),
      amount: (map['amount'] as num?)?.toDouble(),
      itemDescription: map['itemDescription'],
      isAnonymous: map['isAnonymous'] ?? false,
      status: DonationStatus.values.firstWhere(
        (e) => e.name == map['status'],
        orElse: () => DonationStatus.enAttente,
      ),
      proofImageUrl: map['proofImageUrl'],
      createdAt: DateTime.parse(map['createdAt']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'needId': needId,
      'donorId': donorId,
      'type': type.name,
      'amount': amount,
      'itemDescription': itemDescription,
      'isAnonymous': isAnonymous,
      'status': status.name,
      'proofImageUrl': proofImageUrl,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}