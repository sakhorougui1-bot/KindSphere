enum NeedCategory { sante, daraa, aines, familles, nourriture, logement }
enum UrgencyLevel { normal, moyen, urgent }

class NeedModel {
  final String id;
  final String title;
  final String description;
  final String imagePath;
  final String location;
  final NeedCategory category;
  final UrgencyLevel urgency;
  final double targetAmount;
  final double currentAmount;
  final String createdByUserId;
  final bool isVerified;
  final DateTime createdAt;

  NeedModel({
    required this.id,
    required this.title,
    required this.description,
    required this.imagePath,
    required this.location,
    required this.category,
    required this.urgency,
    this.targetAmount = 0.0,
    this.currentAmount = 0.0,
    required this.createdByUserId,
    this.isVerified = false,
    required this.createdAt,
  });

  double get progress => targetAmount > 0 ? (currentAmount / targetAmount).clamp(0.0, 1.0) : 0.0;

  factory NeedModel.fromMap(Map<String, dynamic> map, String id) {
    return NeedModel(
      id: id,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      imagePath: map['imagePath'] ?? 'assets/images/hopital.png',
      location: map['location'] ?? 'Dakar',
      category: NeedCategory.values.firstWhere(
        (e) => e.name == map['category'],
        orElse: () => NeedCategory.sante,
      ),
      urgency: UrgencyLevel.values.firstWhere(
        (e) => e.name == map['urgency'],
        orElse: () => UrgencyLevel.normal,
      ),
      targetAmount: (map['targetAmount'] ?? 0).toDouble(),
      currentAmount: (map['currentAmount'] ?? 0).toDouble(),
      createdByUserId: map['createdByUserId'] ?? '',
      isVerified: map['isVerified'] ?? false,
      createdAt: DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'imagePath': imagePath,
      'location': location,
      'category': category.name,
      'urgency': urgency.name,
      'targetAmount': targetAmount,
      'currentAmount': currentAmount,
      'createdByUserId': createdByUserId,
      'isVerified': isVerified,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}