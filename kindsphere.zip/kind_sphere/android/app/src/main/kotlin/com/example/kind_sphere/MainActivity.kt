package com.example.kind_sphere

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
