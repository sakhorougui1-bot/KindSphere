import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../views/agency/agency_menu_entry.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final email = user?.email ?? '';
    final displayName = (user?.displayName ?? '').trim();
    final name = displayName.isNotEmpty
        ? displayName
        : (email.isNotEmpty ? email.split('@').first : 'Utilisateur');

    return Scaffold(
      backgroundColor: const Color(0xFFF5FAFF),
      appBar: AppBar(
        title: const Text(
          '09. MON PROFIL',
          style: TextStyle(
            color: Color(0xFF123B6D),
            fontSize: 16,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.1,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF123B6D)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          children: [
            const SizedBox(height: 10),
            
            // Avatar de l'utilisateur
            const CircleAvatar(
              radius: 45,
              backgroundColor: Color(0xFF2E6F40), // Fond vert de la maquette
              child: CircleAvatar(
                radius: 42,
                backgroundImage: AssetImage('assets/profile_placeholder.jpeg'),
                // Optionnel si l'image charge mal :
                child: Icon(Icons.person, size: 40, color: Colors.white),
              ),
            ),
            const SizedBox(height: 12),

            // Nom et Email
            Text(
              name,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF123B6D),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              email,
              style: const TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 25),

            // Compteurs (Stats : Dons, Missions, Partages)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatItem('12', 'Dons effectués'),
                _buildStatItem('5', 'Missions'),
                _buildStatItem('3', 'Partages'),
              ],
            ),
            const SizedBox(height: 30),

            // Espace Agence (visible uniquement pour un compte Agence)
            const AgencyMenuEntry(),

            // Premier bloc de menu
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  _buildMenuItem(Icons.checkroom_outlined, 'Mes dons'),
                  const Divider(height: 1, indent: 50, endIndent: 20),
                  _buildMenuItem(Icons.volunteer_activism_outlined, 'Mes missions bénévoles'),
                  const Divider(height: 1, indent: 50, endIndent: 20),
                  _buildMenuItem(Icons.share_outlined, 'Mes partages'),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Second bloc de menu
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  _buildMenuItem(Icons.settings_outlined, 'Paramètres'),
                  const Divider(height: 1, indent: 50, endIndent: 20),
                  _buildMenuItem(Icons.help_outline, 'Aide & support'),
                ],
              ),
            ),
            const SizedBox(height: 30),

            // Bouton Se déconnecter
            TextButton(
              onPressed: () {
                // Action de déconnexion
              },
              child: const Text(
                'Se déconnecter',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // Helper pour les statistiques
  Widget _buildStatItem(String count, String label) {
    return Column(
      children: [
        Text(
          count,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF123B6D),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }

  // Helper pour les items de menu
  Widget _buildMenuItem(IconData icon, String title) {
    return ListTile(
      leading: Icon(icon, color: const Color(0xFF123B6D), size: 22),
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: Color(0xFF123B6D),
        ),
      ),
      trailing: const Icon(Icons.chevron_right, color: Colors.grey, size: 20),
      onTap: () {},
    );
  }
}