
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

//[FirebaseOptions] 

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBPQ1kZi-iikStD6ml5tDc2KCi9E5zeFC8',
    appId: '1:47993784526:web:f39cb0e182165ae987a89f',
    messagingSenderId: '47993784526',
    projectId: 'kindsphere-6377f',
    authDomain: 'kindsphere-6377f.firebaseapp.com',
    storageBucket: 'kindsphere-6377f.firebasestorage.app',
    measurementId: 'G-LZEQMVHJ31',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyD5Hxf2fVmVWbJX-uiS1eBSyzxXbfypyVM',
    appId: '1:47993784526:android:a4afa2633a338eef87a89f',
    messagingSenderId: '47993784526',
    projectId: 'kindsphere-6377f',
    storageBucket: 'kindsphere-6377f.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDlzGitN19xvpxK8V_p-zm9RziFU15QpvA',
    appId: '1:47993784526:ios:fe518c3fbdd2b3b087a89f',
    messagingSenderId: '47993784526',
    projectId: 'kindsphere-6377f',
    storageBucket: 'kindsphere-6377f.firebasestorage.app',
    iosBundleId: 'com.example.kindSphere',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyDlzGitN19xvpxK8V_p-zm9RziFU15QpvA',
    appId: '1:47993784526:ios:fe518c3fbdd2b3b087a89f',
    messagingSenderId: '47993784526',
    projectId: 'kindsphere-6377f',
    storageBucket: 'kindsphere-6377f.firebasestorage.app',
    iosBundleId: 'com.example.kindSphere',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyBPQ1kZi-iikStD6ml5tDc2KCi9E5zeFC8',
    appId: '1:47993784526:web:6ffe3feb894bfa6d87a89f',
    messagingSenderId: '47993784526',
    projectId: 'kindsphere-6377f',
    authDomain: 'kindsphere-6377f.firebaseapp.com',
    storageBucket: 'kindsphere-6377f.firebasestorage.app',
    measurementId: 'G-4LQ25ZMS07',
  );
}
