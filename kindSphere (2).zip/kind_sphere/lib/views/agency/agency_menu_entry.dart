import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../models/stock_model.dart';
import 'agency_stock_page.dart';


class AgencyMenuEntry extends StatelessWidget {
  const AgencyMenuEntry({super.key});

  @override
  Widget build(BuildContext context) {
    final email = FirebaseAuth.instance.currentUser?.email;
    if (!AgencyAccess.isAgency(email)) return const SizedBox.shrink();

    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
          ),
          child: ListTile(
            leading: const Icon(Icons.warehouse_outlined,
                color: Color(0xFF123B6D), size: 22),
            title: const Text(
              'Espace Agence — Gestion des stocks',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Color(0xFF123B6D),
              ),
            ),
            trailing: const Icon(Icons.chevron_right,
                color: Colors.grey, size: 20),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AgencyStockPage()),
              );
            },
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}
