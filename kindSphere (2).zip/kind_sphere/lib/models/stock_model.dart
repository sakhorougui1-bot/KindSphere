import 'package:flutter/material.dart';

// =====================================================
// MODÈLE : GESTION DES STOCKS (ESPACE AGENCE)
// =====================================================

enum StockCategory { vetements, nourriture, materiel, autre }

enum StockStatus { recu, enStock, distribue }

enum DonorType { association, fondation }

extension StockCategoryX on StockCategory {
  String get label {
    switch (this) {
      case StockCategory.vetements:
        return 'Vêtements';
      case StockCategory.nourriture:
        return 'Nourriture';
      case StockCategory.materiel:
        return 'Matériel';
      case StockCategory.autre:
        return 'Autre';
    }
  }

  IconData get icon {
    switch (this) {
      case StockCategory.vetements:
        return Icons.checkroom_outlined;
      case StockCategory.nourriture:
        return Icons.restaurant_outlined;
      case StockCategory.materiel:
        return Icons.inventory_2_outlined;
      case StockCategory.autre:
        return Icons.category_outlined;
    }
  }
}

extension StockStatusX on StockStatus {
  String get label {
    switch (this) {
      case StockStatus.recu:
        return 'Reçu';
      case StockStatus.enStock:
        return 'En stock';
      case StockStatus.distribue:
        return 'Distribué';
    }
  }

  Color get color {
    switch (this) {
      case StockStatus.recu:
        return Colors.orange;
      case StockStatus.enStock:
        return Colors.blue;
      case StockStatus.distribue:
        return Colors.green;
    }
  }
}

extension DonorTypeX on DonorType {
  String get label =>
      this == DonorType.association ? 'Association' : 'Fondation';
}

String formatDate(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

/// Une distribution : une partie du stock remise à une structure bénéficiaire.
class Distribution {
  final String beneficiary;
  final int quantity;
  final DateTime date;

  Distribution({
    required this.beneficiary,
    required this.quantity,
    required this.date,
  });
}

/// Un gros don reçu par l'Agence (association ou fondation).
class StockItem {
  final String id;
  final String donorName;
  final DonorType donorType;
  final String title;
  final StockCategory category;
  final int quantity;
  final String unit;
  final DateTime receivedAt;
  StockStatus status;
  final List<Distribution> distributions;

  StockItem({
    required this.id,
    required this.donorName,
    required this.donorType,
    required this.title,
    required this.category,
    required this.quantity,
    required this.unit,
    required this.receivedAt,
    this.status = StockStatus.enStock,
    List<Distribution>? distributions,
  }) : distributions = distributions ?? [];

  int get distributed =>
      distributions.fold(0, (total, d) => total + d.quantity);

  int get remaining => quantity - distributed;

  double get progress =>
      quantity > 0 ? (distributed / quantity).clamp(0.0, 1.0) : 0.0;
}

/// Accès réservé à l'Agence : liste d'emails autorisés.
/// (Version simple pour le projet ; une version complète utiliserait
/// un champ "role" stocké en base de données.)
class AgencyAccess {
  static const List<String> agencyEmails = [
    'agence@kindsphere.sn',
    'rouguisakho80@gmail.com',
  ];

  static bool isAgency(String? email) {
    if (email == null) return false;
    return agencyEmails.contains(email.trim().toLowerCase());
  }
}

/// Stockage en mémoire (données de démonstration).
class StockRepository {
  StockRepository._();
  static final StockRepository instance = StockRepository._();

  final ValueNotifier<List<StockItem>> items = ValueNotifier<List<StockItem>>([
    StockItem(
      id: 's1',
      donorName: 'Fondation Teranga',
      donorType: DonorType.fondation,
      title: 'Sacs de riz 50 kg',
      category: StockCategory.nourriture,
      quantity: 200,
      unit: 'sacs',
      receivedAt: DateTime(2026, 10, 12),
      distributions: [
        Distribution(
          beneficiary: 'Daara Daroul Hikma',
          quantity: 60,
          date: DateTime(2026, 10, 18),
        ),
      ],
    ),
    StockItem(
      id: 's2',
      donorName: 'Association Solidarité Saint-Louis',
      donorType: DonorType.association,
      title: 'Vêtements pour enfants',
      category: StockCategory.vetements,
      quantity: 500,
      unit: 'pièces',
      receivedAt: DateTime(2026, 10, 20),
    ),
    StockItem(
      id: 's3',
      donorName: 'Fondation Espoir',
      donorType: DonorType.fondation,
      title: 'Lits d’hôpital',
      category: StockCategory.materiel,
      quantity: 20,
      unit: 'unités',
      receivedAt: DateTime(2026, 10, 5),
      status: StockStatus.distribue,
      distributions: [
        Distribution(
          beneficiary: 'Hôpital Principal de Dakar',
          quantity: 20,
          date: DateTime(2026, 10, 9),
        ),
      ],
    ),
  ]);

  StockItem? byId(String id) {
    for (final s in items.value) {
      if (s.id == id) return s;
    }
    return null;
  }

  void add(StockItem item) {
    items.value = [item, ...items.value];
  }

  /// Retourne null si OK, sinon un message d'erreur.
  String? distribute(String id, Distribution d) {
    final item = byId(id);
    if (item == null) return 'Stock introuvable.';
    if (d.quantity <= 0) return 'Quantité invalide.';
    if (d.quantity > item.remaining) {
      return 'Quantité supérieure au stock restant (${item.remaining}).';
    }
    item.distributions.add(d);
    item.status =
        item.remaining == 0 ? StockStatus.distribue : StockStatus.enStock;
    items.value = List<StockItem>.of(items.value); // notifie l'interface
    return null;
  }
}
